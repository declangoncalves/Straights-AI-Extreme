#include "Human.h"
#include <iostream>

void Human::rageQuit() {
  type_ = 'c';
}

Human::Human() {
  type_ = 'h';
}
