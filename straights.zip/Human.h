#ifndef HUMAN_H
#define HUMAN_H

#include "Player.h"
#include "Computer.h"


class Human : public Player {
public:
  Human();
  void rageQuit() override;
};

#endif
